import OpportunitiesPage from '@/components/opportunities/OpportunitiesPage'

export default function SpecialistOpportunitiesPage() {
  return <OpportunitiesPage />
}

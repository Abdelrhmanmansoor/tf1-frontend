import SpecialistDashboard from '@/components/dashboards/SpecialistDashboard'

export default function SpecialistDashboardPage() {
  return <SpecialistDashboard />
}

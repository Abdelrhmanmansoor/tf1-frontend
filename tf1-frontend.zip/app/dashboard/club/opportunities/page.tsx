import OpportunitiesPage from '@/components/opportunities/OpportunitiesPage'

export default function ClubOpportunitiesPage() {
  return <OpportunitiesPage />
}

import OpportunitiesPage from '@/components/opportunities/OpportunitiesPage'

export default function PlayerOpportunitiesPage() {
  return <OpportunitiesPage />
}

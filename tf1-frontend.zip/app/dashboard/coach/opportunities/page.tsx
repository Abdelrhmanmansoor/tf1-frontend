import OpportunitiesPage from '@/components/opportunities/OpportunitiesPage'

export default function CoachOpportunitiesPage() {
  return <OpportunitiesPage />
}

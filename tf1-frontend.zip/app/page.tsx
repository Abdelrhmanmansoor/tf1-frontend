import { LandingPage } from '@/components/landing-page'

export default function HomePage() {
  return <LandingPage />
}
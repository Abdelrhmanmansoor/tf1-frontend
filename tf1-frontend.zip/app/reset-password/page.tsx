import ResetPasswordClient from './reset-password-client'

export default function ResetPasswordPage() {
  return <ResetPasswordClient />
}
